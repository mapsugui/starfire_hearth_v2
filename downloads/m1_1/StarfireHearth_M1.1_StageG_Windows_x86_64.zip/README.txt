Starfire Hearth — M1.1 Stage G desktop review build

These are x86-64 desktop exports from the existing M1 lineage, built for the Stage G review. They are review builds, not a release. Each executable embeds its game data.

Windows: unzip the archive and launch StarfireHearth.exe.

The Windows export was built, but its runtime was not tested in a Windows environment.
